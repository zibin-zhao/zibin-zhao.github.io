# An archive you can open

Canonical art direction for the September 8, 2026 local archive trial. Nine printed, independently selectable leaves and a same-page reader supersede the previous blank-leaf kinetic trial and earlier compositions.

## Composition and meaning

The archive remains the opening's main object: nine curved orange leaves on a visible metal axle, with bearings, screws, and a handle. Each leaf is printed with its own number, real work title, source/category information, a short amount of existing copy, and an action label. The full readable record is available in HTML after selection.

A selected leaf rotates into a reading position while the other leaves move aside. This individual response connects a physical object to its content. Hover provides the entry name and a small visual response. Supporting screens, a record, papers, stones, and a postcard retain the surrounding collection's varied scale and texture.

The same-page reader displays the selected entry, actual links, position within the collection, Previous/Next controls, and nine native selection buttons. It is a reading panel within the homepage, not a separate route. The index visibly identifies the selected entry. The content order is the featured Cas12a paper, CasMD, DL-SELEX, Medit, TEMPO, Singularity, Yaos, the ECG patch paper, and the DNA hydrogel/OECT paper.

Eight destination tags and the site Index remain direct access to the wider portfolio. On portrait screens, the archive has a large opening view, the reader adapts to the available width, and supporting objects continue on the scrollable surface. Interior pages retain the previous fixed backdrop and ordinary reading sheets.

## Materials and provenance

- Chalk `#e8e9e3`, graphite `#232622`, muted text `#60635b`, orange enamel, metal, dark vinyl, paper, and muted green establish the palette.
- Self-hosted Manrope, compact system monospace notes, and system Chinese font fallbacks support the HTML reading layer.
- The instrument and props are authored parametric Three.js geometry with local surface patterns. They are not Blender exports, scans, or downloaded reference-site models.
- Each leaf has its own locally generated canvas print derived from `buildArchiveLeaves`. Printed snippets may wrap or truncate to fit the object; the HTML reader preserves the complete canonical title/description and authors or contribution.
- The reflection environment, warm key, cool edge, hemisphere fill, and ground shadows describe the enamel and metal. Assets remain local.
- Singularity's screen and the Medit/Singularity previews use actual application images. Other supporting printed props and the software display graphic are authored mockups, with no claim that they are working interfaces or real possessions.

The archive's contents come from [the canonical mapping](docs/archive-content.md). Project copy and URLs are reused directly. Paper titles, authors, venue, year, DOI, and any preprint/correction links remain exact. No scientific summary or contribution is invented for the artwork.

## Interaction and motion

The nominal 3.3-second opening camera move yields to user input. Dragging rotates the field; another-angle cycles through three views; reset restores the intended view. Whole-instrument open/close remains separate from choosing an individual content leaf. Ambient motion can be paused.

Selecting a leaf opens its record on the same page and changes that leaf's pose. The native collection launcher and nine-button index provide an alternative to canvas picking. Previous/Next wraps through all entries. Escape and the close button close the reader and restore focus to the launcher. Left/Right keys navigate entries while focus is inside the reader. Dragging must not select a leaf or activate another destination.

Reduced motion starts still and skips the opening camera sequence. Selection immediately updates the chosen reading pose and HTML content, without requiring ambient motion. Pause also preserves deliberate reading actions. Continuous rendering stops when hidden or offscreen; detail, pixel ratio, and frame-rate caps bound rendering work. These limits are not measured frame rates.

The canvas is decorative to assistive technology; HTML controls and source links carry the reading interaction. No loading gate, forced audio, pointer lock, or compulsory camera tour is part of the experience.

## Reading and fallback

Full paper titles and author strings remain in English in both locales. Project descriptions use their existing localized copy. Long titles, authors, addresses, and links wrap within the reader. Keep focus visible, controls reachable, and scrolling available at narrow widths and enlarged text.

The enhanced reader requires the initialized scene. If JavaScript or WebGL is unavailable, the native homepage destinations and site Index still reach the complete portfolio. WebGL failure and context loss hide the reader and inoperative scene controls while exposing the visual fallback. Do not describe the nine-button reader as a no-JavaScript feature.

Interior prompt disclosures, exact copying and manual recovery, filters, downloads, and ordinary reading behavior are retained. CV printing uses the online factual content. Sharing exports should capture the actual current homepage; inspect a newly generated image before identifying an older export as this archive design.

## Implementation and review

`ArchiveReader.astro` supplies the reader's HTML and nine-entry index. `archive-content.ts` maps canonical records. `kinetic-field.ts` connects leaf picking, selected state, camera, HTML controls, and lifecycle; `kinetic-objects.ts` owns printed leaves and their individual articulation. `kinetic-props.ts` retains supporting objects, and `gallery-scene.ts` dispatches the homepage while retaining the interior backdrop.

Review the first, middle, and last entries, direct leaf selection, paging, keyboard close/focus, reduced motion, portrait reading, and fallback. Automated accessibility scans do not certify conformance; geometry complexity and local rendering do not establish performance on all devices. [The archive verification receipt](docs/archive-verification.md) records current results. Earlier kinetic and spatial receipts remain historical records.
