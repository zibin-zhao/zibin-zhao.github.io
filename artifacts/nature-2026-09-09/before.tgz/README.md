# Zibin Zhao

A bilingual personal website built with Astro and Three.js. The current local trial is an interactive archive: nine printed 3D leaves represent real papers and projects. Each leaf can be selected independently and opens its content in a reader on the homepage. Previous/Next and nine native selection buttons reach every entry; Escape closes the reader. This supersedes the previous blank-leaf kinetic trial.

Eight destination tags and the site Index retain direct access to the wider portfolio. Interior routes keep their reading sheets over the fixed 3D backdrop.

The production address is [zibinzhao.com](https://zibinzhao.com/). A local redesign or successful build does not establish that production has changed.

## Development

Use Node 22.13 or newer in a supported even-numbered release.

```sh
npm ci
npm run dev
```

## Quality checks

```sh
npm run verify
npm run test:browser
npm audit
```

`verify` runs Prettier checking, ESLint, Astro type checking, Vitest, and the static build. Browser tests build and start their own local preview, check both locales at desktop and mobile sizes, scan accessibility, and exercise navigation, project filters, clipboard recovery, downloads, and text resizing. Install the browser once with `npx playwright install chromium` if required. Tests disable machine proxy variables in their own process because their server is on loopback. Astro 7's documented foreground setting lets Playwright manage the test server independently of a developer preview.

Run these checks against the current source and inspect the rendered result. Existing receipts under `docs/` describe their dated snapshots; they are not a pass result for subsequent changes. Automated accessibility scans do not certify conformance. WebGL appearance and speed depend on the browser, GPU, viewport, and motion preferences; local checks do not establish performance on every device or production field metrics.

See the [archive verification receipt](docs/archive-verification.md) for this trial's results and pending checks, the [nine-leaf content mapping](docs/archive-content.md) for its records, and the [preservation contract](docs/kinetic-content-check.md) for the underlying routes and content. Earlier [kinetic](docs/kinetic-verification.md) and [spatial](docs/spatial-verification.md) receipts describe their own snapshots; their browser and performance results do not verify this archive interaction.

## Content and design

- [PRODUCT.md](PRODUCT.md): audience, scope, acceptance criteria, and authority.
- [DESIGN.md](DESIGN.md): current visual and interaction system.
- `src/lib/i18n.ts`: English and Chinese routes, labels, and page descriptions.
- `src/views/`: page content, built through `src/pages/[...route].astro`.
- `src/components/`: shared navigation, work cards, publications, and clipboard UI.
- `src/views/Home.astro` and `src/styles/spatial.css`: homepage composition, eight native tags, focus/hover details, controls, and responsive reading layout.
- `src/components/ArchiveReader.astro`: the same-page reading panel, source links, paging, and nine native selection buttons.
- `src/lib/archive-content.ts`: `ArchiveLeaf` and `buildArchiveLeaves(lang, publications)`, reusing the canonical projects and supplied publication records.
- `src/scripts/kinetic-field.ts`: independent leaf selection, reader state, camera, projected tags, lighting, rendering, and fallback lifecycle.
- `src/scripts/kinetic-objects.ts` and `src/scripts/kinetic-props.ts`: individually printed and articulated leaves, plus the supporting collection.
- `src/components/GalleryScene.astro` and `src/scripts/gallery-scene.ts`: scene wrapper, homepage dispatch, and the retained interior backdrop. The previous homepage field renderer has been removed.
- `src/data/projects.ts`: curated work, links, and attributed contributions. Builds do not call GitHub.
- `src/content/publications/`: journal records and the standalone preprint. Keep earlier versions linked to the version of record.
- `src/data/cv.ts` and `src/data/prompts.ts`: CV entries and original English prompt text.
- [Content evidence ledger](docs/content-verification.md): sources and the boundaries of verification.

English routes are canonical at `/`, `/research/`, and similar paths. Chinese routes use `/zh/`. The language switch always links to the same page in the other language. No locale storage or client-side redirect is required.

The portfolio contains six projects, seven journal articles, one standalone preprint, and eight prompt stages with eleven original English prompt blocks. Keep the factual records and public destinations intact when changing their presentation.

The leaf order is the featured Nature Biotechnology Cas12a paper, CasMD, DL-SELEX, Medit, TEMPO, Singularity, Yaos, the ECG patch paper, and the DNA hydrogel/OECT paper. Projects keep their original bilingual descriptions, contributions, and destinations. Papers keep exact full titles, authors, venue/year, DOI, and available earlier-preprint or correction links. Compact surface labels do not replace the full bibliographic record.

The homepage retains its interruptible, nominal 3.3-second opening, whole-instrument open/close, dragging, another-angle, reset, and pause/resume. Choosing a leaf changes its pose and opens its record. The reader supports Previous/Next, direct selection, source links, and Escape/close with focus restoration. Reduced motion starts still and preserves all deliberate selection and reading actions. Portrait layouts adapt the reader within the continuous collection. The enhanced archive reader requires JavaScript and WebGL; native destination links and the site Index continue to reach all portfolio content if it is unavailable.

## Images and exports

Astro builds responsive WebP images from `src/assets/`. Medit and Singularity previews are screenshots from their actual interfaces, and the Singularity screen uses that real preview as its texture. The instrument and props use authored parametric Three.js geometry and local surface patterns, with environment reflections, key/fill lighting, and ground shadows. Each archive leaf has its own canvas print generated from its real content record. The objects are not Blender exports or photorealistic scans. Supporting printed props and the software display graphic are decorative mockups, not working interfaces or biographical evidence.

The export utility uses the installed Playwright package and accepts only a localhost or `127.0.0.1` preview URL. By default it writes both `public/cv.pdf` and `public/og.png`:

```sh
npm run build
npm run preview -- --host 127.0.0.1 --port 43219
node tools/generate-exports.mjs http://127.0.0.1:43219
npm run build
```

To refresh only the sharing image and leave the existing CV PDF untouched:

```sh
node tools/generate-exports.mjs http://127.0.0.1:43219 --og-only
```

The sharing export captures the real homepage at 1200 by 630 pixels, preserving its scene, tags, navigation, and controls. It fits the spatial surface to that frame, starts with reduced motion, and waits for fonts, preview images, and an explicit scene `ready` or `fallback` state. Its readiness check uses the canvas's CSS dimensions and a positive drawing buffer, allowing the renderer's capped pixel ratio. A scene that remains loading makes the export fail instead of recording an unfinished view. The command reports whether it captured WebGL or the fallback; inspect that distinction when reviewing the result.

Review every generated CV page and the sharing image. Check text, reading order, page breaks, clipping, and the captured field before treating the export as complete. The CV uses the same content as the web page, plus print-specific styling. Do not maintain a separate duplicate CV template.

## Embedded applications

`public/medit/` and `public/singularity/` are separately built applications. The portfolio only curates their entry links and previews. When changing Medit's precached HTML, update its `index.html` revision in `sw.js` and test an existing-client update plus offline reload. Never describe a fresh-install-only check as update coverage.

## Deployment

The existing GitHub Pages workflow runs on pushes to `main`. This experimental trial is local and reviewable; no merge, push, or deployment is included. Production publication requires explicit authority. When an authorized change is successfully merged into `main`, push `main` to `origin`, allow deployment to propagate, and verify the live site separately. Current product and design definitions supersede earlier compositions; dated verification documents remain historical evidence for their own snapshots.
