# A lake, a small world, a universe

The approved starting point is the misty lake. The September 9 revision carries that visual care through every homepage chapter and replaces the earlier separate panels and screenshot covers.

## Composition

A single sticky photographic surface sits behind a normally scrolling document. Lake, fern, breathing lake, stars, and forest blend as their chapters approach. Transitions finish before the visitor settles into a chapter, avoiding ghost images behind its title. Ordinary anchors retain the ability to jump directly to any scene.

A small point of light connects the water, the detail of a leaf, breathing rings, the stars, and the forest trail. The metaphor expresses curiosity, not a scientific mechanism.

The research uses three small annotations over a full-frame fern photograph. Medit becomes an original typographic composition over water. Its slow elliptical rings breathe around the title. Singularity becomes an original particle illustration occupying most of the viewport. Four other records appear along a lightly traced forest path. The final scene reduces the biography to the name, three places, and two personal links.

All nine reading records retain complete canonical information. The page avoids visible paragraphs of project descriptions. The reader and document pages provide the deeper layer on request.

## Material and motion

Keep the original photographic mist, forest green, muted ivory, and Manrope. The final Chinese name uses local Kai typography as a personal sign-off. Photography is real and credited; the rings and star artwork are authored with CSS, SVG, and canvas. No generated raster assets or fabricated application screenshots are used.

The lake retains its WebGL2 water enhancement. A separate canvas draws the decorative galaxy with deterministic particles. It is an illustration of the project, not an astronomical simulation. Pointer movement changes its tilt slightly. The reader never depends on either renderer.

Motion follows normal scroll events without wheel interception. Reduced motion removes camera movement and autonomous animation. A shared control pauses water, rings, and stars; another instance remains available beside the chapter navigation. Water and stars suspend frame rendering offscreen and when the document is hidden. Image layers remain static when their renderer is unavailable.

Desktop uses full-viewport compositions with sparse, placed links. Phone layouts retain the full-frame scenery and redistribute those links to avoid covering the focal detail. The same new Medit and Singularity cover language appears on Projects.

## Evidence and scope

Sources remain in `docs/nature-assets.md`. Current visual and behavior evidence is recorded in `docs/journey-verification.md`. Earlier receipts document earlier implementations. The change remains local until publication is explicitly authorized.
