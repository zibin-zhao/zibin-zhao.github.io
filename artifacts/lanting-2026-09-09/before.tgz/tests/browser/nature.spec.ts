import { test, expect, type Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { projects } from '../../src/data/projects';

const hero = '[data-nature-hero]';
const dialog = '[data-work-dialog]';
const titles = [
  'DNA-guided Cas12a',
  'CasMD',
  'DL-SELEX',
  'Medit',
  'TEMPO',
  'Singularity',
  'Yaos',
  '12-lead ECG patch',
  'DNA hydrogel + OECT',
];

async function ready(page: Page) {
  await expect(page.locator(hero)).toHaveAttribute('data-water-state', /^(ready|fallback)$/);
  await expect(page.locator('[data-nature-home]')).toHaveAttribute('data-journey-ready', 'true');
  await expect(page.locator('[data-lake-photo]')).toBeVisible();
}

for (const lang of ['en', 'zh'] as const) {
  test(`${lang} nature collection opens all nine exact records and restores focus`, async ({
    page,
  }) => {
    await page.goto(lang === 'en' ? '/' : '/zh/');
    await ready(page);
    const launcher = page.locator('[data-work-open="0"]').first();
    await launcher.click();
    await expect(page.locator(dialog)).toBeVisible();
    await expect(page.locator('[data-reader-select] option')).toHaveCount(9);
    for (let index = 0; index < titles.length; index++) {
      await page.locator('[data-reader-select]').selectOption(String(index));
      const article = page.locator(`[data-reader-entry="${index}"]`);
      await expect(article).toBeVisible();
      await expect(page.locator('[data-reader-entry]:visible')).toHaveCount(1);
      await expect(article.locator('.reader-summary')).not.toBeEmpty();
      await expect(article.locator('.reader-detail')).not.toBeEmpty();
      if (lang === 'en')
        await expect(page.locator('[data-reader-title]')).toHaveText(titles[index]!);
      if (index > 0 && index < 7) {
        const project = projects[index - 1]!;
        await expect(article.locator('.reader-summary')).toHaveText(project.summary[lang]);
        await expect(article.locator('.reader-detail')).toHaveText(project.contribution[lang]);
        await expect(article.locator('.reader-links a').first()).toHaveAttribute(
          'href',
          project.href,
        );
      }
      for (const link of await article.locator('a').all()) {
        await expect(link).toBeVisible();
        expect(await link.getAttribute('href')).toMatch(/^(https:\/\/|\/(medit|singularity)\/)/);
      }
    }
    await page.keyboard.press('Escape');
    await expect(page.locator(dialog)).not.toBeVisible();
    await expect(launcher).toBeFocused();
  });
}

test('reader paging wraps and keyboard controls retain canonical destinations', async ({
  page,
}) => {
  await page.goto('/');
  await page.locator('[data-work-open="0"]').first().click();
  await page.locator('[data-reader-prev]').click();
  await expect(page.locator('[data-reader-title]')).toHaveText(titles[8]!);
  await page.locator('[data-reader-next]').click();
  await expect(page.locator('[data-reader-title]')).toHaveText(titles[0]!);
  await page.keyboard.press('ArrowRight');
  await expect(page.locator('[data-reader-title]')).toHaveText('CasMD');
  await page.keyboard.press('ArrowLeft');
  await expect(page.locator('[data-reader-title]')).toHaveText(titles[0]!);
  const results = await new AxeBuilder({ page })
    .include(dialog)
    .withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'])
    .analyze();
  expect(results.violations).toEqual([]);
  await page.locator('[data-reader-close]').click();
  await expect(page.locator(dialog)).not.toBeVisible();
});

test('reading works even when WebGL is unavailable', async ({ page }) => {
  await page.addInitScript(() => {
    const getContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (
      this: HTMLCanvasElement,
      type: string,
      ...args: unknown[]
    ) {
      if (type === 'webgl' || type === 'webgl2') return null;
      return Reflect.apply(getContext, this, [type, ...args]);
    } as typeof getContext;
  });
  await page.goto('/');
  await expect(page.locator(hero)).toHaveAttribute('data-water-state', 'fallback');
  await expect(page.locator('[data-lake-photo]')).toBeVisible();
  // The shared control still pauses the breathing cover and 2D constellation.
  await expect(page.locator('[data-nature-motion]')).toBeVisible();
  await page.locator('[data-work-open="3"]').click();
  await expect(page.locator('[data-reader-title]')).toHaveText('Medit');
  await expect(page.locator('[data-reader-entry="3"] a')).toHaveAttribute('href', '/medit/');
  await page.locator('[data-reader-close]').click();
  await expect(page.locator('[data-work-open="3"]')).toBeFocused();
});

test('water pauses actual rendering, responds to a touch, and stops offscreen', async ({
  page,
}) => {
  await page.goto('/');
  await ready(page);
  const scene = page.locator(hero);
  await expect(scene).toHaveAttribute('data-water-state', 'ready');
  const toggle = page.locator('[data-nature-motion]');
  await toggle.click();
  const still = await scene.getAttribute('data-water-frames');
  await page.waitForTimeout(180);
  expect(await scene.getAttribute('data-water-frames')).toBe(still);
  await toggle.click();
  await expect.poll(() => scene.getAttribute('data-water-frames')).not.toBe(still);
  const box = (await scene.boundingBox())!;
  const point = {
    x: box.width * 0.55,
    y: Math.min(box.height * 0.64, page.viewportSize()!.height - 100),
  };
  await page.mouse.click(point.x, point.y);
  await expect(scene).toHaveAttribute('data-water-ripples', /^[1-9]\d*$/);
  await page.locator('#work-title').scrollIntoViewIfNeeded();
  await expect
    .poll(() => scene.evaluate((el) => el.getBoundingClientRect().bottom))
    .toBeLessThan(0);
  await page.waitForTimeout(150);
  const outside = await scene.getAttribute('data-water-frames');
  await page.waitForTimeout(180);
  expect(await scene.getAttribute('data-water-frames')).toBe(outside);
});

test('reduced motion starts still and preference changes take effect', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  await ready(page);
  await expect(page.locator(hero)).toHaveAttribute('data-water-motion', 'paused');
  const still = await page.locator(hero).getAttribute('data-water-frames');
  await page.waitForTimeout(180);
  expect(await page.locator(hero).getAttribute('data-water-frames')).toBe(still);
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await expect(page.locator(hero)).toHaveAttribute('data-water-motion', 'playing');
  await expect.poll(() => page.locator(hero).getAttribute('data-water-frames')).not.toBe(still);
});

test('context loss leaves the photograph, reader, and download usable', async ({ page }) => {
  await page.goto('/');
  await ready(page);
  await page
    .locator('[data-lake-canvas]')
    .evaluate((canvas: HTMLCanvasElement) =>
      canvas.getContext('webgl2')!.getExtension('WEBGL_lose_context')!.loseContext(),
    );
  await expect(page.locator(hero)).toHaveAttribute('data-water-state', 'fallback');
  await expect(page.locator('[data-lake-photo]')).toBeVisible();
  await expect(page.locator('[data-postcard]')).toBeEnabled();
  await page.locator('[data-work-open="0"]').first().click();
  await expect(page.locator(dialog)).toBeVisible();
});

test('a postcard is an actual downloadable PNG with the expected dimensions', async ({ page }) => {
  await page.goto('/');
  await ready(page);
  const downloadPromise = page.waitForEvent('download');
  await page.locator('[data-postcard]').click();
  const download = await downloadPromise;
  expect(download.suggestedFilename()).toBe('a-moment-with-zibin.png');
  const stream = await download.createReadStream();
  const chunks: Buffer[] = [];
  for await (const chunk of stream!) chunks.push(Buffer.from(chunk));
  const buffer = Buffer.concat(chunks);
  expect(buffer.subarray(1, 4).toString()).toBe('PNG');
  expect(buffer.readUInt32BE(16)).toBe(1800);
  expect(buffer.readUInt32BE(20)).toBe(1200);
  await download.saveAs(`artifacts/journey-2026-09-09/postcard.png`);
  await expect(page.locator('[data-postcard-status]')).toHaveText('Your postcard is downloaded.');
});

test('the complete portfolio remains navigable with JavaScript disabled', async ({
  browser,
  isMobile,
}) => {
  const context = await browser.newContext({
    javaScriptEnabled: false,
    viewport: isMobile ? { width: 390, height: 844 } : { width: 1440, height: 1000 },
  });
  const page = await context.newPage();
  await page.goto('http://127.0.0.1:43217/');
  await expect(page.locator('[data-lake-photo]')).toBeVisible();
  await expect(page.locator('[data-nature-controls]')).toBeHidden();
  await expect(page.locator('[data-work-open]')).toHaveCount(9);
  await page.locator('.garden-medit').click();
  await expect(page).toHaveURL(/\/medit\/$/);
  await context.close();
});

test('returning from an application restores a readable homepage', async ({ page }) => {
  await page.goto('/');
  await page.locator('.garden-medit').click();
  await page.locator('[data-reader-entry="3"] a').click();
  await expect(page).toHaveURL(/\/medit\/$/);
  await page.goBack();
  await expect(page.locator(dialog)).not.toBeVisible();
  await page.locator('.garden-medit').click();
  await expect(page.locator('[data-reader-title]')).toHaveText('Medit');
});

test('nature compositions retain visible content at desktop and portrait sizes', async ({
  page,
}, testInfo) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  await ready(page);
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('#home-title')).toBeInViewport();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({ path: `artifacts/journey-2026-09-09/${testInfo.project.name}-home.png` });
  for (const [index, id] of ['research', 'work', 'universe', 'field', 'person'].entries()) {
    if (index === 0)
      await page.getByRole('link', { name: 'Come a little closer', exact: true }).click();
    else await page.locator(`[data-journey-stops] a[href="#${id}"]`).click();
    await expect(page.locator('[data-nature-home]')).toHaveAttribute(
      'data-active-chapter',
      String(index + 1),
    );
    const layer = page.locator(`[data-world-layer="${Math.min(index + 1, 4)}"]`);
    await expect(layer).toHaveCSS('opacity', '1');
    await layer
      .locator('img')
      .evaluateAll((images: HTMLImageElement[]) =>
        Promise.all(images.map((image) => image.decode())),
      );
    await page.screenshot({
      path: `artifacts/journey-2026-09-09/${testInfo.project.name}-${id}.png`,
    });
  }
});

test('the shared motion control pauses the universe and rendering stops after leaving it', async ({
  page,
}) => {
  await page.goto('/');
  await ready(page);
  await page.getByRole('link', { name: 'Come a little closer', exact: true }).click();
  await page.locator('[data-journey-stops] a[href="#universe"]').click();
  const canvas = page.locator('[data-constellation]');
  const first = await canvas.getAttribute('data-constellation-frames');
  await expect.poll(() => canvas.getAttribute('data-constellation-frames')).not.toBe(first);
  await page.locator('[data-journey-motion]').click();
  await expect(page.locator('[data-journey-motion]')).toHaveAttribute('aria-pressed', 'true');
  const still = await canvas.getAttribute('data-constellation-frames');
  await page.waitForTimeout(180);
  expect(await canvas.getAttribute('data-constellation-frames')).toBe(still);
  await page.locator('[data-journey-motion]').click();
  await expect.poll(() => canvas.getAttribute('data-constellation-frames')).not.toBe(still);
  await page.locator('[data-journey-stops] a[href="#person"]').click();
  await expect(page.locator('[data-nature-home]')).toHaveAttribute('data-active-chapter', '5');
  await page.waitForTimeout(150);
  const outside = await canvas.getAttribute('data-constellation-frames');
  await page.waitForTimeout(180);
  expect(await canvas.getAttribute('data-constellation-frames')).toBe(outside);
});

test('a missing 2D canvas retains the star illustration and the complete reader', async ({
  page,
}) => {
  await page.addInitScript(() => {
    const original = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (
      this: HTMLCanvasElement,
      type: string,
      ...args: unknown[]
    ) {
      if (type === '2d') return null;
      return Reflect.apply(original, this, [type, ...args]);
    } as typeof original;
  });
  await page.goto('/#universe');
  await ready(page);
  await expect(page.locator('.still-stars')).toBeVisible();
  await page.locator('.garden-singularity').click();
  await expect(page.locator('[data-reader-title]')).toHaveText('Singularity');
  await expect(page.locator('[data-reader-entry="5"] a')).toHaveAttribute('href', '/singularity/');
});
