# Zibin Zhao

A bilingual personal website built with Astro. The current local design follows one continuous visual journey from a misty lake into a fern, breathing water, a particle universe, and a forest. Surface copy is minimal; complete research and project records open in an independent HTML reader.

The production address is [zibinzhao.com](https://zibinzhao.com/). Local work does not change that deployment.

## Development

Use Node 22.13 or newer in a supported even-numbered release.

```sh
npm ci
npm run dev
npm run verify
npm run test:browser
```

Static verification includes formatting, lint, Astro checks, unit tests, and a static build. Browser tests build their own local preview and exercise desktop and mobile, both languages, accessibility, keyboard use, reading, water lifecycle, downloads, no JavaScript, no WebGL, filters, clipboard recovery, and text resizing. Install Chromium with `npx playwright install chromium` when required.

## Current implementation

- `src/views/Home.astro`: the photographic narrative and links to the actual work.
- `src/components/JourneyScenery.astro`: layered photographs and a static star fallback.
- `src/styles/nature.css` and `src/styles/journey.css`: the shared reading skin and full-frame story compositions.
- `src/scripts/nature-home.ts`: the independent reader, shared motion control, and postcard download.
- `src/scripts/nature-journey.ts`: scenery transitions, chapter navigation, and the decorative galaxy.
- `src/components/ProjectArtwork.astro`: original Medit and Singularity cover compositions for Projects.
- `src/scripts/lake-water.ts`: the small WebGL2 water enhancement and lifecycle handling.
- `src/components/NatureReader.astro`: nine server-rendered records with real source links.
- `src/lib/archive-content.ts`: existing canonical mapping of six projects and three selected papers.
- `src/data/`, `src/content/publications/`, and `src/views/`: factual records, both locales, and the full portfolio.

See [PRODUCT.md](PRODUCT.md), [DESIGN.md](DESIGN.md), [asset provenance](docs/nature-assets.md), and [the current verification receipt](docs/journey-verification.md). Earlier dated receipts describe their own historical implementations. The immediately preceding nature design is preserved in `artifacts/journey-2026-09-09/before.tgz`.

## Content contracts

Fourteen bilingual portfolio URLs, six projects, seven journal articles, one standalone preprint, eight prompt stages, eleven original English prompt blocks, CV PDF, contact destinations, and both embedded apps are preserved. English routes use `/` and Chinese routes use `/zh/`. Language navigation links to the same page in the other language.

Homepage links retain their normal destinations without JavaScript. With JavaScript, a native dialog presents the selected full record. This reader does not depend on the water renderer. WebGL failure leaves the photograph and all content usable. The whole portfolio remains readable without animation.

## Images and exports

Astro generates local responsive WebP assets. Nature images are real licensed photographs with attribution in the footer. Project covers are original compositions using those photographs and code-drawn rings or stars. The old application screenshots remain in source as historical assets. No external image request is required by the built homepage.

Refresh the sharing image from a local preview:

```sh
node tools/generate-exports.mjs http://127.0.0.1:43230 --og-only
npm run build
```

Omitting `--og-only` also regenerates the CV PDF. Inspect a regenerated PDF before replacing a verified export. The OG utility waits for the real first frame, fonts, and images and captures 1200 by 630 pixels with reduced motion.

The visitor postcard is a separate 1800 by 1200 PNG produced in the browser, with credit to Simona D'Auria. No data leaves the browser.

## Embedded applications and delivery

`public/medit/` and `public/singularity/` are independently built applications. Their bundles remain outside this visual redesign. Changing Medit's precached entry point requires a corresponding service-worker revision and an existing-client update check.

This revision is local and reviewable. Publication requires explicit authority. After an authorized merge into main, push main to origin, allow GitHub Pages to update, and verify the live site separately. Browser scans and local rendering do not establish production field performance or coverage on every device.
