# Follow a little curiosity

Canonical target for September 9, 2026, following the user's review of the first nature version.

## Accepted direction and replacement

Keep the misty lake, large name, calm photographic light, and water response. Replace the separate green research panel, conventional project list, and application screenshot covers. The canonical experience is now one visual journey, with continuous scenery and very little surface copy.

## Journey

1. Arrive at the lake and meet Zibin.
2. Move into the fern's fine texture. Three small annotations open the research records.
3. Let the lake become Medit: one full-frame composition with breathing water rings.
4. Let a point of light become Singularity: a slowly moving, interactive star field.
5. Find other work along a quiet trail through the forest.
6. Meet the person behind it all, with the existing Xinhui, Melbourne, and Hong Kong path.

Full information stays in the native reader and dedicated pages. Surface copy names the moments and works; it does not explain the interaction or repeat the full descriptions. New cover artwork also appears on Projects.

## Preserved contracts

Fourteen bilingual URLs, six projects, eight publication records, exact author/title/source relationships, CV PDF, eight prompt stages with eleven source blocks, contact destinations, and the two embedded applications remain intact. This changes presentation, not scientific content or the applications themselves.

Native scrolling, real anchor destinations, keyboard access, language continuity, source downloads, and the independent reading dialog remain required. Reduced motion and a shared pause control govern the animated scenes. Photographs and a static star illustration remain when rendering is unavailable.

## Delivery

Run the static checks and browser suite; inspect actual desktop and phone compositions and transitions. The current receipt is `docs/journey-verification.md`. The previous nature source is preserved in `artifacts/journey-2026-09-09/before.tgz`.

Local delivery only. No merge, push, or deployment is included.
