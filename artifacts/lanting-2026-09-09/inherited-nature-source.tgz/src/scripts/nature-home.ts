const home = document.querySelector<HTMLElement>('[data-nature-home]');

if (home) {
  const lang = home.dataset.lang;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const hero = home.querySelector<HTMLElement>('[data-nature-hero]')!;
  const photo = home.querySelector<HTMLImageElement>('[data-lake-photo]')!;
  const controls = home.querySelector<HTMLElement>('[data-nature-controls]')!;
  const motion = home.querySelector<HTMLButtonElement>('[data-nature-motion]')!;
  const journeyMotion = home.querySelector<HTMLButtonElement>('[data-journey-motion]')!;
  controls.hidden = false;
  motion.hidden = false;
  let motionPaused = reduced.matches;
  const syncMotion = () => {
    home.toggleAttribute('data-motion-paused', motionPaused);
    hero.dataset.waterMotion = motionPaused ? 'paused' : 'playing';
    motion.setAttribute('aria-pressed', String(motionPaused));
    motion.querySelector('[data-motion-label]')!.textContent =
      (motionPaused ? motion.dataset.play : motion.dataset.pause) || '';
    journeyMotion.setAttribute('aria-pressed', String(motionPaused));
    journeyMotion.setAttribute(
      'aria-label',
      (motionPaused ? motion.dataset.play : motion.dataset.pause) || '',
    );
    home.dispatchEvent(new CustomEvent('nature:motion', { detail: motionPaused }));
  };
  motion.addEventListener('click', () => {
    motionPaused = !motionPaused;
    syncMotion();
  });
  journeyMotion.addEventListener('click', () => motion.click());
  reduced.addEventListener('change', () => {
    motionPaused = reduced.matches;
    syncMotion();
  });
  syncMotion();

  // The photographic first frame and reading layer never wait for WebGL.
  import('./lake-water')
    .then(({ createLake }) => createLake(hero, photo, reduced))
    .catch(() => {
      hero.dataset.waterState = 'fallback';
    });

  import('./nature-journey')
    .then(({ createJourney }) => createJourney(home, reduced))
    .catch(() => {
      home.dataset.journeyFallback = 'true';
    });

  const dialog = home.querySelector<HTMLDialogElement>('[data-work-dialog]')!;
  const records = [...dialog.querySelectorAll<HTMLElement>('[data-reader-entry]')];
  const title = dialog.querySelector<HTMLElement>('[data-reader-title]')!;
  const selector = dialog.querySelector<HTMLSelectElement>('[data-reader-select]')!;
  const readerStatus = dialog.querySelector<HTMLElement>('[data-reader-status]')!;
  let selected = 0;
  let launcher: HTMLElement | null = null;
  const select = (index: number) => {
    selected = (index + records.length) % records.length;
    records.forEach((record, i) => {
      record.hidden = i !== selected;
    });
    title.textContent = records[selected]!.dataset.title || '';
    selector.value = String(selected);
    readerStatus.textContent = `${selected + 1} / ${records.length}: ${title.textContent}`;
    dialog.scrollTop = 0;
  };
  home.querySelectorAll<HTMLAnchorElement>('[data-work-open]').forEach((link) => {
    link.addEventListener('click', (event) => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      launcher = link;
      select(Number(link.dataset.workOpen));
      dialog.showModal();
    });
  });
  dialog.querySelector('[data-reader-close]')?.addEventListener('click', () => dialog.close());
  dialog.querySelector('[data-reader-prev]')?.addEventListener('click', () => select(selected - 1));
  dialog.querySelector('[data-reader-next]')?.addEventListener('click', () => select(selected + 1));
  selector.addEventListener('change', () => select(Number(selector.value)));
  dialog.addEventListener('keydown', (event) => {
    if (event.target === selector || event.altKey || event.metaKey || event.ctrlKey) return;
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      event.preventDefault();
      select(selected + (event.key === 'ArrowLeft' ? -1 : 1));
    }
  });
  dialog.addEventListener('click', (event) => {
    if (event.target !== dialog) return;
    const box = dialog.getBoundingClientRect();
    if (
      event.clientX < box.left ||
      event.clientX > box.right ||
      event.clientY < box.top ||
      event.clientY > box.bottom
    )
      dialog.close();
  });
  dialog.addEventListener('close', () => launcher?.focus({ preventScroll: true }));
  // A browser history restore returns to the collection, with no modal scroll lock.
  window.addEventListener('pageshow', () => {
    if (dialog.open) dialog.close();
  });

  const postcard = home.querySelector<HTMLButtonElement>('[data-postcard]')!;
  const postcardStatus = home.querySelector<HTMLElement>('[data-postcard-status]')!;
  postcard.addEventListener('click', async () => {
    postcard.disabled = true;
    try {
      await document.fonts.ready;
      const source = new Image();
      source.src = hero.dataset.postcardSrc!;
      await source.decode();
      const canvas = document.createElement('canvas');
      canvas.width = 1800;
      canvas.height = 1200;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas unavailable');
      ctx.fillStyle = '#152e29';
      ctx.fillRect(0, 0, 1800, 1200);
      ctx.drawImage(source, 0, 0, source.naturalWidth, source.naturalHeight, 40, 40, 1720, 1050);
      ctx.fillStyle = '#203a34';
      ctx.font = '400 210px Manrope, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Zibin Zhao', 900, 440);
      ctx.fillStyle = '#e2e9dd';
      ctx.font = '24px Manrope, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('A little curiosity. A moment to keep.', 60, 1150);
      ctx.textAlign = 'right';
      ctx.fillText('zibinzhao.com', 1740, 1150);
      // The credit belongs to the actual photographer, not the portfolio owner.
      ctx.font = '16px Manrope, sans-serif';
      ctx.fillStyle = '#b6c7b7';
      ctx.fillText('Photograph: Simona D’Auria / Unsplash', 1740, 1182);
      const blob = await new Promise<Blob>((resolve, reject) =>
        canvas.toBlob(
          (value) => (value ? resolve(value) : reject(new Error('Export failed'))),
          'image/png',
        ),
      );
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = 'a-moment-with-zibin.png';
      document.body.append(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      postcardStatus.textContent =
        lang === 'zh' ? '明信片已下载。' : 'Your postcard is downloaded.';
    } catch {
      postcardStatus.textContent =
        lang === 'zh'
          ? '暂时无法保存，请再试一次。'
          : 'Could not save the postcard. Please try again.';
    } finally {
      postcard.disabled = false;
    }
  });
}

export {};
