// The document scrolls normally. Only the scenery interpolates between chapter positions.
export function createJourney(home: HTMLElement, reduced: MediaQueryList): void {
  const world = home.querySelector<HTMLElement>('[data-journey-world]')!;
  const chapters = [...home.querySelectorAll<HTMLElement>('[data-chapter]')];
  const layers = [...world.querySelectorAll<HTMLElement>('[data-world-layer]')];
  const stops = home.querySelector<HTMLElement>('[data-journey-stops]')!;
  const stopLinks = [...stops.querySelectorAll<HTMLAnchorElement>('a[data-stop]')];
  const glint = world.querySelector<HTMLElement>('[data-journey-glint]')!;
  const clamp = (value: number) => Math.max(0, Math.min(1, value));
  const smooth = (value: number) => {
    const t = clamp(value);
    return t * t * (3 - 2 * t);
  };
  let positions: number[] = [];
  let viewport = innerHeight;
  let scrollFrame = 0;
  let motionPaused = home.hasAttribute('data-motion-paused');
  let active = 0;
  const glintPositions = [
    [54, 69],
    [68, 50],
    [50, 54],
    [51, 42],
    [70, 66],
    [50, 82],
  ];
  const measure = () => {
    viewport = world.clientHeight;
    positions = chapters.map((chapter) => chapter.getBoundingClientRect().top + scrollY);
  };
  const paint = () => {
    scrollFrame = 0;
    const y = scrollY;
    layers.forEach((layer) => {
      const index = Number(layer.dataset.worldLayer);
      const amount = smooth((y - (positions[index]! - viewport * 0.5)) / (viewport * 0.43));
      layer.style.setProperty('--layer-opacity', String(amount));
    });
    active = 0;
    chapters.forEach((_, index) => {
      if (y + viewport * 0.5 >= positions[index]!) active = index;
    });
    home.dataset.activeChapter = String(active);
    stopLinks.forEach((link, i) => {
      if (i === active) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
    // No camera movement when the visitor requests reduced motion.
    const first = clamp(y / viewport);
    world.style.setProperty('--lake-scale', String(reduced.matches ? 1 : 1 + first * 0.13));
    const close = clamp((y - positions[1]!) / viewport);
    world.style.setProperty('--fern-scale', String(reduced.matches ? 1.14 : 1.14 + close * 0.15));
    const forest = clamp((y - positions[4]!) / (viewport * 2));
    world.style.setProperty('--forest-scale', String(reduced.matches ? 1.1 : 1.1 - forest * 0.1));
    const next = Math.min(active + 1, chapters.length - 1);
    const blend = smooth(
      (y - positions[active]!) / Math.max(1, positions[next]! - positions[active]!),
    );
    const a = glintPositions[active]!;
    const b = glintPositions[next]!;
    glint.style.setProperty('--glint-x', String(a[0]! + (b[0]! - a[0]!) * blend) + '%');
    glint.style.setProperty('--glint-y', String(a[1]! + (b[1]! - a[1]!) * blend) + '%');
    glint.style.setProperty('--glint-opacity', active === 3 || active === 5 ? '0' : '0.75');
    const inHome = y < home.offsetTop + home.offsetHeight - innerHeight * 0.2;
    stops.hidden = !inHome || active === 0;
  };
  const schedule = () => {
    if (!scrollFrame) scrollFrame = requestAnimationFrame(paint);
  };
  const resize = new ResizeObserver(() => {
    measure();
    schedule();
  });
  resize.observe(home);
  resize.observe(world);
  window.addEventListener('scroll', schedule, { passive: true });
  window.addEventListener('resize', schedule, { passive: true });
  window.addEventListener('pageshow', () => {
    measure();
    schedule();
  });
  home.dataset.journeyReady = 'true';
  measure();
  paint();

  // Pointer drift is a small lens shift, never a prerequisite for reading.
  home.addEventListener(
    'pointermove',
    (event) => {
      if (reduced.matches || motionPaused || event.pointerType === 'touch') return;
      world.style.setProperty('--dew-x', String((event.clientX / innerWidth - 0.5) * 14) + 'px');
      world.style.setProperty('--dew-y', String((event.clientY / innerHeight - 0.5) * 12) + 'px');
    },
    { passive: true },
  );

  const canvas = world.querySelector<HTMLCanvasElement>('[data-constellation]')!;
  const ctx = canvas.getContext('2d', { alpha: true });
  if (!ctx) return; // The server-rendered star illustration remains visible.
  let width = 1;
  let height = 1;
  let time = 0;
  let last = 0;
  let frame = 0;
  let frames = 0;
  let onScreen = false;
  let pointerX = 0;
  let pointerY = 0;
  let seed = 290919;
  const random = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  const points = Array.from({ length: innerWidth < 761 ? 3800 : 10000 }, (_, i) => {
    const r = Math.pow(random(), 1.45);
    const arm = i % 3;
    const angle = (arm * Math.PI * 2) / 3 + (1 - r) * 7.8 + (random() - 0.5) * (0.16 + r * 0.95);
    return {
      r,
      angle,
      z: (random() - 0.5) * (0.1 + r * 0.24),
      size: 0.45 + random() * 0.85,
      light: 0.3 + random() * 0.65,
    };
  });
  const distant = Array.from({ length: 140 }, () => ({
    x: random(),
    y: random(),
    light: 0.15 + random() * 0.35,
  }));
  const render = () => {
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#e8edcf';
    for (const star of distant) {
      ctx.globalAlpha = star.light;
      ctx.fillRect(star.x * width, star.y * height, 0.9, 0.9);
    }
    const radius = Math.min(width * 0.42, height * 0.61);
    const centerX = width * 0.51;
    const centerY = height * 0.43;
    const tilt = -0.24 + pointerX * 0.04;
    const cos = Math.cos(tilt),
      sin = Math.sin(tilt);
    const bloom = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius * 0.5);
    bloom.addColorStop(0, '#e8edcb28');
    bloom.addColorStop(1, '#e8edcb00');
    ctx.globalAlpha = 1;
    ctx.fillStyle = bloom;
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = '#ebefce';
    for (const point of points) {
      const angle = point.angle + time * 0.025;
      const x = Math.cos(angle) * point.r;
      const y = Math.sin(angle) * point.r * (0.37 + pointerY * 0.035) + point.z * 0.35;
      const px = centerX + (x * cos - y * sin) * radius;
      const py = centerY + (x * sin + y * cos) * radius;
      ctx.globalAlpha = point.light * (0.9 - point.r * 0.22);
      ctx.fillRect(px, py, point.size, point.size);
    }
    ctx.globalAlpha = 1;
    canvas.dataset.constellationFrames = String(++frames);
  };
  const tick = (now: number) => {
    frame = 0;
    if (motionPaused || reduced.matches || !onScreen || document.hidden) return;
    if (now - last >= 1000 / 30) {
      time += Math.min((now - last) / 1000, 0.08);
      last = now;
      render();
    }
    frame = requestAnimationFrame(tick);
  };
  const sync = () => {
    cancelAnimationFrame(frame);
    frame = 0;
    if (!motionPaused && !reduced.matches && onScreen && !document.hidden) {
      last = performance.now();
      frame = requestAnimationFrame(tick);
    }
  };
  const resizeCanvas = () => {
    width = world.clientWidth;
    height = world.clientHeight;
    const ratio = Math.min(devicePixelRatio, 1.5);
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    render();
  };
  const canvasResize = new ResizeObserver(resizeCanvas);
  canvasResize.observe(world);
  const cosmosObserver = new IntersectionObserver(
    ([entry]) => {
      onScreen = Boolean(entry?.isIntersecting);
      sync();
    },
    { rootMargin: '30% 0px 0px' },
  );
  cosmosObserver.observe(chapters[3]!);
  home.addEventListener(
    'pointermove',
    (event) => {
      if (motionPaused || reduced.matches || event.pointerType === 'touch') return;
      pointerX = event.clientX / innerWidth - 0.5;
      pointerY = event.clientY / innerHeight - 0.5;
    },
    { passive: true },
  );
  home.addEventListener('nature:motion', (event) => {
    motionPaused = (event as CustomEvent<boolean>).detail;
    sync();
  });
  reduced.addEventListener('change', () => {
    schedule();
    sync();
  });
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('pagehide', (event) => {
    cancelAnimationFrame(frame);
    cancelAnimationFrame(scrollFrame);
    if (!event.persisted) {
      resize.disconnect();
      canvasResize.disconnect();
      cosmosObserver.disconnect();
    }
  });
  window.addEventListener('pageshow', sync);
  resizeCanvas();
  world.dataset.constellationReady = 'true';
}
