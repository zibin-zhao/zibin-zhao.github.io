# A small corner of Zibin's world

Canonical target for September 9, 2026. The nature experience supersedes the orange mechanical archive, kinetic object collection, and earlier gallery compositions. Their source and tests are preserved in `artifacts/nature-2026-09-09/before.tgz`.

## Outcome

Introduce Zibin Zhao as a person through a calm, memorable natural environment. The first viewport should invite a pause. Research, projects, and personal interests appear as parts of the same journey, with short surface copy and full records on demand.

## Experience

- An actual foggy-lake photograph frames the name and a restrained water reflection. A small WebGL shader animates only the water; touches and pointer movement create ripples. A pause control and reduced-motion support keep the experience optional.
- A close view of a fern introduces the research. Three featured records open the complete source information without leaving the scene. All publications remain on Research.
- Medit and Singularity use real application screenshots. CasMD, DL-SELEX, TEMPO, and Yaos remain visible, with all six projects accessible in the homepage reader and on Projects.
- The final forest scene introduces the person, using the existing Xinhui, Melbourne, Hong Kong, and interests copy. About, CV, contact, and the prompt library remain available through native navigation.
- Visitors can download a locally composed landscape postcard with photographer credit. Nothing is uploaded and no audio starts automatically.

## Preserved contracts

Fourteen bilingual URLs, six projects, eight publication records, exact author/title/source relationships, the CV PDF, eight prompt stages with eleven source blocks, contact details, and both embedded applications remain intact. Full records reuse the existing content mapping; short labels do not replace the source text. This is a presentation change, not a scientific reanalysis.

All links retain their real destinations without JavaScript. The reader requires JavaScript but works independently of WebGL. The initial photograph, navigation, and content remain visible when animation is unavailable. Keyboard navigation, locale continuity, project filters, clipboard fallback, downloads, hashes, and 404 recovery remain supported.

## Acceptance

Inspect desktop and portrait compositions. Verify all nine reading records, focus restoration, next/previous and direct selection, real destinations, no JavaScript, no WebGL, context loss, pause, reduced motion, offscreen suspension, postcard output, both languages, and 320 px with 200 percent text. Run the existing static gates and the browser suite. Record actual results in `docs/nature-verification.md`.

## Delivery boundary

This implementation is local. No merge, push, or deployment is included. The existing production workflow applies after a separately authorized merge to main.
