// A small photographic water shader. The HTML image remains underneath at all times.
// No scene graph, geometry download, or animation library is needed for this surface.
export async function createLake(
  hero: HTMLElement,
  photo: HTMLImageElement,
  button: HTMLButtonElement,
  reduced: MediaQueryList,
): Promise<void> {
  const canvas = hero.querySelector<HTMLCanvasElement>('[data-lake-canvas]')!;
  const gl = canvas.getContext('webgl2', {
    alpha: false,
    antialias: false,
    depth: false,
    powerPreference: 'low-power',
  });
  if (!gl) {
    hero.dataset.waterState = 'fallback';
    return;
  }
  const compile = (type: number, code: string) => {
    const shader = gl.createShader(type)!;
    gl.shaderSource(shader, code);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      gl.deleteShader(shader);
      throw new Error('Water shader could not compile');
    }
    return shader;
  };
  const vertex = compile(
    gl.VERTEX_SHADER,
    `#version 300 es
    in vec2 aPosition;
    out vec2 vUv;
    void main() { vUv = aPosition * .5 + .5; gl_Position = vec4(aPosition, 0., 1.); }
  `,
  );
  const fragment = compile(
    gl.FRAGMENT_SHADER,
    `#version 300 es
    precision highp float;
    uniform sampler2D uPhoto;
    uniform vec2 uSize;
    uniform float uImageAspect;
    uniform float uTime;
    uniform vec4 uRipples[6];
    in vec2 vUv;
    out vec4 color;
    void main() {
      float aspect = uSize.x / uSize.y;
      vec2 fit = vec2(min(aspect / uImageAspect, 1.), min(uImageAspect / aspect, 1.));
      vec2 uv = (vUv - .5) * fit + .5;
      float water = 1. - smoothstep(.32, .405, uv.y);
      vec2 displacement = vec2(sin(uv.y * 190. + uTime * .55) * .0008, sin(uv.x * 110. + uv.y * 70. + uTime * .35) * .00025);
      for (int i = 0; i < 6; i++) {
        float age = uTime - uRipples[i].z;
        vec2 delta = (vUv - uRipples[i].xy) * vec2(aspect, 1.);
        float distanceToRing = length(delta);
        float ring = distanceToRing - age * .065;
        float envelope = exp(-abs(ring) * 45.) * exp(-age * .72) * step(0., age) * uRipples[i].w;
        displacement += normalize(delta + .00001) * sin(ring * 125.) * envelope * .007;
      }
      color = texture(uPhoto, clamp(uv + displacement * water, .001, .999));
    }
  `,
  );
  const program = gl.createProgram()!;
  gl.attachShader(program, vertex);
  gl.attachShader(program, fragment);
  gl.linkProgram(program);
  gl.deleteShader(vertex);
  gl.deleteShader(fragment);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    gl.deleteProgram(program);
    throw new Error('Water shader could not link');
  }
  gl.useProgram(program);
  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const position = gl.getAttribLocation(program, 'aPosition');
  gl.enableVertexAttribArray(position);
  gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
  const texture = gl.createTexture();
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  await photo.decode();
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, photo);
  gl.uniform1i(gl.getUniformLocation(program, 'uPhoto'), 0);
  gl.uniform1f(
    gl.getUniformLocation(program, 'uImageAspect'),
    photo.naturalWidth / photo.naturalHeight,
  );
  const sizeUniform = gl.getUniformLocation(program, 'uSize');
  const timeUniform = gl.getUniformLocation(program, 'uTime');
  const rippleUniform = gl.getUniformLocation(program, 'uRipples[0]');
  const ripples = new Float32Array(24);
  let rippleIndex = 0;
  let time = 0;
  let paused = reduced.matches;
  let visible = true;
  let lost = false;
  let raf = 0;
  let last = 0;
  let lastPointer = 0;
  let frames = 0;
  const render = () => {
    if (lost) return;
    gl.uniform1f(timeUniform, time);
    gl.uniform4fv(rippleUniform, ripples);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    hero.dataset.waterFrames = String(++frames);
  };
  const tick = (now: number) => {
    raf = 0;
    if (paused || !visible || document.hidden || lost) return;
    if (now - last >= 1000 / 30) {
      time += Math.min((now - last) / 1000, 0.08);
      last = now;
      render();
    }
    raf = requestAnimationFrame(tick);
  };
  const sync = () => {
    cancelAnimationFrame(raf);
    raf = 0;
    hero.dataset.waterMotion = paused ? 'paused' : 'playing';
    button.setAttribute('aria-pressed', String(paused));
    button.querySelector('[data-motion-label]')!.textContent =
      (paused ? button.dataset.play : button.dataset.pause) || '';
    if (!paused && visible && !document.hidden && !lost) {
      last = performance.now();
      raf = requestAnimationFrame(tick);
    }
  };
  const resize = () => {
    if (lost) return;
    const ratio = Math.min(devicePixelRatio, innerWidth < 761 ? 1.25 : 1.5);
    canvas.width = Math.round(hero.clientWidth * ratio);
    canvas.height = Math.round(hero.clientHeight * ratio);
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.uniform2f(sizeUniform, canvas.width, canvas.height);
    render();
  };
  const observer = new IntersectionObserver(([entry]) => {
    visible = Boolean(entry?.isIntersecting);
    sync();
  });
  observer.observe(hero);
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(hero);
  document.addEventListener('visibilitychange', sync);
  button.addEventListener('click', () => {
    paused = !paused;
    sync();
  });
  reduced.addEventListener('change', () => {
    paused = reduced.matches;
    sync();
  });
  const ripple = (event: PointerEvent) => {
    if (paused || reduced.matches || lost || (event.target as Element).closest('a, button')) return;
    const now = performance.now();
    if (event.type === 'pointermove' && (event.pointerType === 'touch' || now - lastPointer < 260))
      return;
    lastPointer = now;
    const bounds = hero.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width;
    const y = 1 - (event.clientY - bounds.top) / bounds.height;
    if (y > 0.5) return;
    ripples.set([x, y, time, 1], (rippleIndex++ % 6) * 4);
    hero.dataset.waterRipples = String(rippleIndex);
  };
  hero.addEventListener('pointermove', ripple, { passive: true });
  hero.addEventListener('pointerdown', ripple, { passive: true });
  const stop = () => {
    lost = true;
    cancelAnimationFrame(raf);
    observer.disconnect();
    resizeObserver.disconnect();
    hero.dataset.waterState = 'fallback';
    button.hidden = true;
  };
  canvas.addEventListener('webglcontextlost', stop);
  window.addEventListener('pagehide', (event) => {
    cancelAnimationFrame(raf);
    if (!event.persisted) {
      stop();
      gl.deleteTexture(texture);
      gl.deleteBuffer(buffer);
      gl.deleteProgram(program);
    }
  });
  window.addEventListener('pageshow', sync);
  hero.dataset.waterState = 'ready';
  button.hidden = false;
  resize();
  sync();
}
