# A walk from the lake

Canonical art direction for September 9, 2026. This replaces the orange archive and mechanical objects with photography, natural texture, restrained motion, and direct reading. Existing factual content and public routes are retained.

## Visual direction

The opening is a real misty lake, with the name occupying the space above the water. Manrope is used for the display and reading layer; the Chinese wordmark is plain typography. A faint reflected name connects the typography to the landscape. The first frame is visible immediately, with no loading gate or delayed title fade.

The photograph fades into a single forest-green ground, `#152e29`, with pale foliage text `#f0f2e9` and muted text `#b5c4b8`. Interior pages share these materials. The lake's lighter mist is photographic light, not a second unrelated theme. The display rhythm moves from the wide name to a circular fern close-up, an asymmetric arrangement of real app previews, and a short personal letter in a forest scene.

Design read: a personal nature portfolio, replacing the previous visual direction. Design variance 8, motion intensity 4, visual density 2. Native Astro, CSS, and a small WebGL2 shader are sufficient. There is no scene-graph dependency in the portfolio bundle.

## Motion with a purpose

- Water responds to pointer movement or touch in the lower part of the opening. Ambient displacement is slow and localized to the photographed water.
- The fern enlarges around the pointer to reward looking closely.
- Medit's actual screenshot responds like a small print; Singularity's image retains its original particle universe.
- Scrolled sections enter gently. Normal vertical scrolling is never intercepted.
- Reading opens in a native modal dialog. All nine records can be selected directly or reached through previous/next and arrow keys. Escape or close returns focus to the initiating link.
- The postcard action downloads an actual PNG with a new composition, the site address, and the actual photographer's credit.

Reduced motion starts still. Pause stops continuous canvas rendering; hidden and offscreen states suspend it. WebGL failure and context loss expose the original photograph and retain the independent reader. Pixel density is capped at 1.5 on desktop and 1.25 on mobile, and rendering is capped at 30 updates per second. These are implementation limits, not measured device performance claims.

## Sources and truth

All three nature images are licensed Unsplash photographs, not generated imagery or Zibin's personal travel photographs. Sources and local hashes are recorded in `docs/nature-assets.md`. Medit and Singularity previews are existing screenshots. No image is presented as a molecular structure, research result, or personal possession.

The full paper titles, authors, DOI/version relationships, project descriptions, and contributions come from the existing records. The visual summary for Cas12a refers to RNA recognition and cleavage, consistent with the existing title. A landscape or plant is a visual metaphor only.

## Surfaces and constraints

Circles are used for looking into a natural detail, the particle universe, and compact directional controls. Reading panels and app images remain rectangular. Z-order is limited to scenery, content, navigation, the skip link, and the browser's native dialog layer.

Mobile uses a stacked name and a single-column story. The menu remains a native details element at every width. Photo credits sit in a footer disclosure. Print styling retains a white CV surface. The complete pre-change source is retained as a recovery archive, while inactive scene code and obsolete scene tests are removed from the working source.
